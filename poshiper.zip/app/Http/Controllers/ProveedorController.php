<?php

namespace App\Http\Controllers;

class ProveedorController extends Controller
{
    //
}
