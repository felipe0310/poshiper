<?php

namespace App\Http\Controllers;

class EmpresaController extends Controller
{
    //
}
