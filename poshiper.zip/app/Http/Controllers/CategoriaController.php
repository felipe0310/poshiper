<?php

namespace App\Http\Controllers;

class CategoriaController extends Controller
{
    public function index()
    {

    }
}
