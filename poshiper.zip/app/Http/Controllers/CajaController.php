<?php

namespace App\Http\Controllers;

class CajaController extends Controller
{
    //
}
