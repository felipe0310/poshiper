<?php

namespace App\Http\Controllers;

class CompraController extends Controller
{
    //
}
