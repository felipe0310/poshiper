<?php

namespace App\Http\Controllers;

class VentaCabeceraController extends Controller
{
    //
}
