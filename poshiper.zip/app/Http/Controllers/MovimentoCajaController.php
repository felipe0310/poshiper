<?php

namespace App\Http\Controllers;

class MovimentoCajaController extends Controller
{
    //
}
