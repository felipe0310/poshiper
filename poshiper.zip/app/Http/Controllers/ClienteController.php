<?php

namespace App\Http\Controllers;

class ClienteController extends Controller
{
    //
}
