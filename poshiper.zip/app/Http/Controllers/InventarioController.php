<?php

namespace App\Http\Controllers;

class InventarioController extends Controller
{
    //
}
