<?php

namespace App\Http\Controllers;

class EmpleadoController extends Controller
{
    //
}
