<?php

namespace App\Http\Controllers;

class DepositoController extends Controller
{
    //
}
