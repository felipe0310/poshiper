<?php

namespace App\Http\Controllers;

class DetalleCompraController extends Controller
{
    //
}
