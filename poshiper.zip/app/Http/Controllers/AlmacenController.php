<?php

namespace App\Http\Controllers;

class AlmacenController extends Controller
{
    //
}
