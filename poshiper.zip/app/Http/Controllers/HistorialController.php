<?php

namespace App\Http\Controllers;

class HistorialController extends Controller
{
    //
}
