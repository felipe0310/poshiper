<?php

namespace App\Http\Controllers;

class ProductoController extends Controller
{
    public function index()
    {

    }
}
