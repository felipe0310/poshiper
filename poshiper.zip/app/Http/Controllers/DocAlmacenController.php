<?php

namespace App\Http\Controllers;

class DocAlmacenController extends Controller
{
    //
}
