<?php

namespace App\Http\Controllers;

class VentaDetalleController extends Controller
{
    //
}
