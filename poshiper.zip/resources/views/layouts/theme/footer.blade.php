{{-- <div class="footer-wrapper">
    <div class="footer-section f-section-1">
        <p class="">Sistema Hiper Pos</p>
    </div>
    <div class="footer-section f-section-2">
        <p class="">Versión 1.0.0 - by Felipe López</p>
    </div>
</div> --}}

<div class="footer-wrapper">
    <div class="footer-section f-section-1">
        <p class="">Hiper Pañal - Sistema POS</p>
    </div>
    <div class="footer-section f-section-2">
        <p class="">V 1.0.0 - Dev Felipe López Oñate</p>
    </div>
</div>
