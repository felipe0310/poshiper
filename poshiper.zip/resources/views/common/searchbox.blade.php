<div class="mt-2 mb-4">
    <input  type="text" wire:model ="buscar" placeholder="Buscar" class="form-control">
</div>
