<div>
    <div class="page-header">
        <div class="page-title">
            <h3><?php echo e($nombreComponente); ?> | <?php echo e($paginaTitulo); ?></h3>
        </div>
    </div>    
    <div class="row">
        <?php $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $almacen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 mt-2">
                <div class="card text-center border-primary">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($almacen->descripcion); ?></h5>
                        <p class="card-text"><?php echo e($almacen->ubicacion); ?></p>
                        <button wire:click="verSucursal(<?php echo e($almacen->id); ?>)" class="btn btn-info">Ir a Inventario</button>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\poshiper\resources\views/livewire/inventario/inventarios.blade.php ENDPATH**/ ?>