<div wire:ignore.self class="modal fade" id="theModal" tabindex="-1" role="dialog" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background: #0654a1">
                <h5 class="modal-title text-white">
                    <b><?php echo e($nombreComponente); ?></b> | <?php echo e($seleccionar_id > 0 ? 'EDITAR' : 'CREAR'); ?>

                </h5>
                <h6 class="text-center text-warning" wire:loading>Por Favor Espere</h6>
            </div>
            <div class="modal-body">
<?php /**PATH C:\xampp\htdocs\poshiper\resources\views/common/modalHead.blade.php ENDPATH**/ ?>